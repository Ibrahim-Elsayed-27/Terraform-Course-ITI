import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # Parse the SNS message containing S3 event
    for record in event['Records']:
        sns_message = json.loads(record['Sns']['Message'])
        # S3 event structure
        if 'Records' in sns_message:
            for s3_record in sns_message['Records']:
                event_name = s3_record['eventName']
                bucket_name = s3_record['s3']['bucket']['name']
                object_key = s3_record['s3']['object']['key']
                object_size = s3_record['s3']['object']['size']
                
                change_details = f"Event: {event_name}, Bucket: {bucket_name}, Key: {object_key}, Size: {object_size} bytes"
        else:
            change_details = sns_message.get('change_details', 'No details provided')
        
        # Send email
        ses_client = boto3.client('ses', region_name='eu-central-1')
        try:
            response = ses_client.send_email(
                Source='ibrahim.elsayed.stud@gmail.com',
                Destination={
                    'ToAddresses': ['ibrahim.elsayed.stud@gmail.com']
                },
                Message={
                    'Subject': {
                        'Data': 'Terraform Statefile Update Notification'
                    },
                    'Body': {
                        'Text': {
                            'Data': f'An update has happened to the statefile. Details: {change_details}'
                        }
                    }
                }
            )
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:", response['MessageId'])
